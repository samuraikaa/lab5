<?php
// admin_add_kard_dom.php

include 'admin_header.php';

// Ваш код для добавления карточки дома в таблицу "kard_doms" базы данных

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получите данные формы
    $agentId = $_POST['agent_id'];
    $address = $_POST['address'];
    $price = $_POST['price'];
    $country = $_POST['country'];
    $bedrooms = $_POST['bedrooms'];
    $bathrooms = $_POST['bathrooms'];

    // Ваш код для добавления карточки дома в таблицу "kard_doms" базы данных

    // Перенаправление на страницу карточек домов
    header("Location: admin_kard_doms.php");
    exit;
}

?>

<!-- Форма для добавления карточки дома -->
<form method="POST" action="">
    <label for="agent_id">Agent ID:</label>
    <input type="text" name="agent_id" required><br>

    <label for="address">Address:</label>
    <input type="text" name="address" required><br>

    <label for="price">Price:</label>
    <input type="text" name="price" required><br>

    <label for="country">Country:</label>
    <input type="text" name="country" required><br>

    <label for="bedrooms">Bedrooms:</label>
    <input type="text" name="bedrooms" required><br>

    <label for="bathrooms">Bathrooms:</label>
    <input type="text" name="bathrooms" required><br>

    <button type="submit">Add Kard Dom</button>
</form>

<?php include 'admin_footer.php'; ?>
