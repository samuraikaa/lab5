<?php
// admin_reports.php

include 'admin_header.php';

// Ваш код для страницы отчетов админ-панели

?>

<!-- HTML-разметка страницы отчетов -->
<h1>Admin Reports</h1>
<p>Here you can view and generate reports for your estate agency.</p>

<?php include 'admin_footer.php'; ?>
