<?php
// admin_add_news.php

include 'admin_header.php';

// Ваш код для добавления новости в таблицу "news" базы данных

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получите данные формы
    $title = $_POST['title'];
    $description = $_POST['description'];

    // Ваш код для добавления новости в таблицу "news" базы данных

    // Перенаправление на страницу новостей
    header("Location: admin_news.php");
    exit;
}

?>

<!-- Форма для добавления новости -->
<form method="POST" action="">
    <label for="title">Title:</label>
    <input type="text" name="title" required><br>

    <label for="description">Description:</label>
    <textarea name="description" required></textarea><br>

    <button type="submit">Add News</button>
</form>

<?php include 'admin_footer.php'; ?>
