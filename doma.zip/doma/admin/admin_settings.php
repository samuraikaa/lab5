<?php
// admin_settings.php

include 'admin_header.php';

// Ваш код для страницы настроек админ-панели

?>

<!-- HTML-разметка страницы настроек -->
<h1>Admin Settings</h1>
<p>Here you can configure the settings of the admin panel.</p>

<?php include 'admin_footer.php'; ?>
