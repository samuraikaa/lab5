<?php
// admin_edit_kard_dom.php

include 'admin_header.php';

// Ваш код для редактирования карточки дома в таблице "kard_doms" базы данных

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получите данные формы
    $kardDomId = $_POST['kard_dom_id'];
    $agentId = $_POST['agent_id'];
    $address = $_POST['address'];
    $price = $_POST['price'];
    $country = $_POST['country'];
    $bedrooms = $_POST['bedrooms'];
    $bathrooms = $_POST['bathrooms'];

    // Ваш код для обновления данных карточки дома в таблице "kard_doms" базы данных

    // Перенаправление на страницу карточек домов
    header("Location: admin_kard_doms.php");
    exit;
}

// Получите данные карточки дома для предварительного заполнения формы
$kardDomId = $_GET['kard_dom_id'];

// Ваш код для получения данных карточки дома из таблицы "kard_doms" базы данных

?>

<!-- Форма для редактирования карточки дома -->
<form method="POST" action="">
    <input type="hidden" name="kard_dom_id" value="<?php echo $kardDomId; ?>">

    <label for="agent_id">Agent ID:</label>
    <input type="text" name="agent_id" value="<?php echo $agentId; ?>" required><br>

    <label for="address">Address:</label>
    <input type="text" name="address" value="<?php echo $address; ?>" required><br>

    <label for="price">Price:</label>
    <input type="text" name="price" value="<?php echo $price; ?>" required><br>

    <label for="country">Country:</label>
    <input type="text" name="country" value="<?php echo $country; ?>" required><br>

    <label for="bedrooms">Bedrooms:</label>
    <input type="text" name="bedrooms" value="<?php echo $bedrooms; ?>" required><br>

    <label for="bathrooms">Bathrooms:</label>
    <input type="text" name="bathrooms" value="<?php echo $bathrooms; ?>" required><br>

    <button type="submit">Update Kard Dom</button>
</form>

<?php include 'admin_footer.php'; ?>
