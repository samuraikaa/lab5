<?php
// admin_footer.php

// Ваш код для подвала админ-панели

?>

<!-- HTML-разметка подвала -->
<footer>
    <p>&copy; 2023 Estate Agency. All rights reserved.</p>
</footer>
