<?php
// admin_news.php

include 'admin_header.php';

// Ваш код для работы с таблицей "news" базы данных

// Пример кода для получения данных из таблицы "news"
$sql = "SELECT * FROM news";
$result = mysqli_query($connection, $sql);

if (mysqli_num_rows($result) > 0) {
    // Вывод данных
    while ($row = mysqli_fetch_assoc($result)) {
        echo "News ID: " . $row['news_id'] . "<br>";
        echo "Title: " . $row['title'] . "<br>";
        echo "Description: " . $row['description'] . "<br>";
        echo "<br>";
    }
} else {
    echo "No news found";
}

?>

<?php include 'admin_footer.php'; ?>
