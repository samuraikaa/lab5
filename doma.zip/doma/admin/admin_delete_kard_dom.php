<?php
// admin_delete_kard_dom.php

// Ваш код для удаления карточки дома из таблицы "kard_doms" базы данных

// Перенаправление на страницу карточек домов
header("Location: admin_kard_doms.php");
exit;
?>
