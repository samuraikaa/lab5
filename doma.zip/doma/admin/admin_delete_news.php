<?php
// admin_delete_news.php

// Ваш код для удаления новости из таблицы "news" базы данных

// Перенаправление на страницу новостей
header("Location: admin_news.php");
exit;
?>
