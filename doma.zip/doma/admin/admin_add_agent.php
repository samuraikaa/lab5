<?php
// admin_add_agent.php

include 'admin_header.php';

// Ваш код для добавления агента в таблицу "agents" базы данных

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получите данные формы
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $description = $_POST['description'];

    // Ваш код для добавления агента в таблицу "agents" базы данных

    // Перенаправление на страницу агентов
    header("Location: admin_agents.php");
    exit;
}

?>

<!-- Форма для добавления агента -->
<form method="POST" action="">
    <label for="first_name">First Name:</label>
    <input type="text" name="first_name" required><br>

    <label for="last_name">Last Name:</label>
    <input type="text" name="last_name" required><br>

    <label for="description">Description:</label>
    <textarea name="description" required></textarea><br>

    <button type="submit">Add Agent</button>
</form>

<?php include 'admin_footer.php'; ?>
