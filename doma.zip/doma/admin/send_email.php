<?php
require_once '../vendor/phpmailer/PHPMailerAutoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Функция для генерации случайного кода
function generateRandomCode($length = 6) {
    $characters = '0123456789';
    $code = '';
    for ($i = 0; $i < $length; $i++) {
        $code .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $code;
}

// Параметры отправки почты
$host = 'smtp.example.com';
$port = 587;
$username = 'enot_beceljiak@mail.ru';
$password = 'e5mguvYnwk0BsKXNmj73';
$fromEmail = 'your_email@example.com';
$fromName = 'Your Name';

// Получатель письма
$toEmail = 'recipient@example.com';
$toName = 'Recipient Name';

// Генерация случайного кода
$code = generateRandomCode();

// Создание объекта PHPMailer
$mail = new PHPMailer(true);

try {
    // Настройка параметров отправки почты
    $mail->isSMTP();
    $mail->Host = $host;
    $mail->Port = $port;
    $mail->SMTPAuth = true;
    $mail->Username = $username;
    $mail->Password = $password;
    $mail->SMTPSecure = 'tls';

    // Установка отправителя и получателя
    $mail->setFrom($fromEmail, $fromName);
    $mail->addAddress($toEmail, $toName);

    // Установка темы и содержимого письма
    $mail->Subject = 'Код для входа в админ-панель';
    $mail->Body = 'Ваш код для входа в админ-панель: ' . $code;

    // Отправка письма
    $mail->send();

    // Вывод сообщения об успешной отправке
    echo 'Письмо успешно отправлено';
} catch (Exception $e) {
    // Вывод сообщения об ошибке
    echo 'Ошибка отправки письма: ' . $mail->ErrorInfo;
}
?>
