<?php
// admin_agents.php

include 'admin_header.php';

// Ваш код для работы с таблицей "agents" базы данных

// Пример кода для получения данных из таблицы "agents"
$sql = "SELECT * FROM agents";
$result = mysqli_query($connection, $sql);

if (mysqli_num_rows($result) > 0) {
    // Вывод данных
    while ($row = mysqli_fetch_assoc($result)) {
        echo "Agent ID: " . $row['agent_id'] . "<br>";
        echo "First Name: " . $row['first_name'] . "<br>";
        echo "Last Name: " . $row['last_name'] . "<br>";
        echo "Description: " . $row['description'] . "<br>";
        echo "<br>";
    }
} else {
    echo "No agents found";
}

?>

<?php include 'admin_footer.php'; ?>
