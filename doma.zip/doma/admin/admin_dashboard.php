<?php
// admin_dashboard.php

include 'admin_header.php';

// Ваш код для отображения контента панели управления админ-панелью
?>

<?php include 'admin_footer.php'; ?>
