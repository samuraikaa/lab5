<?php
// admin_header.php

// Проверка авторизации админа
// Если не авторизован, перенаправление на страницу входа
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
?>

<!-- HTML-разметка заголовка -->
<header>
    <h1>Admin Panel</h1>
    <nav>
        <ul>
            <li><a href="admin_index.php">Home</a></li>
            <li><a href="admin_kard_doms.php">Kard Doms</a></li>
            <li><a href="admin_agents.php">Agents</a></li>
            <li><a href="admin_news.php">News</a></li>
            <li><a href="admin_settings.php">Settings</a></li>
            <li><a href="admin_reports.php">Reports</a></li>
        </ul>
    </nav>
</header>
