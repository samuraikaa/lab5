<?php
// admin_logout.php

session_start();

// Очистка сессии админа
session_unset();
session_destroy();

// Перенаправление на страницу входа
header("Location: admin_login.php");
exit;
?>
