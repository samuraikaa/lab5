<?php
// admin_kard_doms.php

include 'admin_header.php';

// Ваш код для получения списка карточек домов из таблицы "kard_doms" базы данных

?>

<!-- Отображение списка карточек домов -->
<table>
    <tr>
        <th>ID</th>
        <th>Agent ID</th>
        <th>Address</th>
        <th>Price</th>
        <th>Country</th>
        <th>Bedrooms</th>
        <th>Bathrooms</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($kardDoms as $kardDom): ?>
        <tr>
            <td><?php echo $kardDom['kard_dom_id']; ?></td>
            <td><?php echo $kardDom['agent_id']; ?></td>
            <td><?php echo $kardDom['address']; ?></td>
            <td><?php echo $kardDom['price']; ?></td>
            <td><?php echo $kardDom['country']; ?></td>
            <td><?php echo $kardDom['bedrooms']; ?></td>
            <td><?php echo $kardDom['bathrooms']; ?></td>
            <td>
                <a href="admin_edit_kard_dom.php?kard_dom_id=<?php echo $kardDom['kard_dom_id']; ?>">Edit</a>
                <a href="admin_delete_kard_dom.php?kard_dom_id=<?php echo $kardDom['kard_dom_id']; ?>">Delete</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<?php include 'admin_footer.php'; ?>
