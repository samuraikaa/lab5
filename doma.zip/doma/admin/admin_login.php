<?php
// admin_login.php

session_start();

// Функция для отправки электронной почты
function sendEmail($to, $subject, $message) {
    // Здесь вам нужно использовать вашу логику отправки электронной почты
    // Можно использовать встроенную функцию mail() или библиотеки для отправки почты, такие как PHPMailer или SwiftMailer
    // В этом примере используется функция mail()
    // Убедитесь, что ваш сервер настроен для отправки электронной почты
    
    // Для примера используется функция mail()
    // Установите заголовки и отправьте письмо
    $headers = "From: enot_beceljiak@mail.ru" . "\r\n" .
               "Reply-To: enot_beceljiak@mail.ru" . "\r\n" .
               "Content-type: text/html; charset=UTF-8" . "\r\n" .
               "X-Mailer: PHP/" . phpversion();
    mail($to, $subject, $message, $headers);
}

// Проверка авторизации админа

// Проверка отправленных данных формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $captcha = $_POST['captcha'];

    // Проверка капчи
    if (!isset($_SESSION['captcha_code']) || $captcha !== $_SESSION['captcha_code']) {
        // Капча не прошла проверку, перенаправление на страницу входа с сообщением об ошибке
        header("Location: admin_login.php?error=captcha");
        exit;
    }

    // Проверка данных админа (здесь необходимо добавить вашу логику проверки данных)
    if ($email === 'proverkamail61@mail.ru' && $password === '123') {
        // Вход выполнен успешно, установка сессии админа
        $_SESSION['admin'] = true;

        // Отправка письма с кодом на почту админу
        $code = mt_rand(100000, 999999); // Генерация случайного кода
        $to = $email;
        $subject = "Код для входа в админ-панель";
        $message = "Ваш код для входа в админ-панель: $code";
        sendEmail($to, $subject, $message);

        // Перенаправление на страницу ввода кода
        header("Location: admin_verify.php?email=" . urlencode($email));
        exit;
    } else {
        // Данные админа неверны, перенаправление на страницу входа с сообщением об ошибке
        header("Location: admin_login.php?error=invalid");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Вход в админ-панель</title>
    <link rel="stylesheet" type="text/css" href="./admin.css">
</head>
<body>
    <div class="login-container">
        <h1>Вход в админ-панель</h1>
        <?php if (isset($_GET['error'])) : ?>
            <p class="error-message">
                <?php if ($_GET['error'] === 'captcha') : ?>
                    Код капчи неверный. Пожалуйста, попробуйте снова.
                <?php elseif ($_GET['error'] === 'invalid') : ?>
                    Неправильный email или пароль. Пожалуйста, попробуйте снова.
                <?php endif; ?>
            </p>
        <?php endif; ?>
        <form method="POST" action="admin_login.php"> <!-- Исправлен путь для отправки формы -->
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <img src="captcha.php" alt="Капча">
            <input type="text" name="captcha" placeholder="Введите код капчи" required>
            <button type="submit">Войти</button>
        </form>
    </div>
</body>
</html>
