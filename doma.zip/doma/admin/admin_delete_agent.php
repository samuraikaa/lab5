<?php
// admin_delete_agent.php

// Ваш код для удаления агента из таблицы "agents" базы данных

// Перенаправление на страницу агентов
header("Location: admin_agents.php");
exit;
?>
