<?php
// admin_verify.php

// Проверка параметра email в URL
if (!isset($_GET['email'])) {
    // Если параметр email отсутствует, перенаправление на страницу входа
    header("Location: admin_login.php");
    exit;
}

// Получение значения email из параметра URL
$email = $_GET['email'];

// Проверка отправленной формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $verificationCode = $_POST['verification_code'];

    // Проверка кода верификации (здесь необходимо добавить вашу логику проверки кода)
    if ($verificationCode === '653780') {
        // Код верификации прошел успешно, установка сессии админа
        session_start();
        $_SESSION['admin'] = true;

        // Перенаправление на главную страницу админ-панели
        header("Location: admin_index.php");
        exit;
    } else {
        // Неправильный код верификации, перенаправление на страницу ввода кода с сообщением об ошибке
        header("Location: admin_verify.php?email=" . urlencode($email) . "&error=invalid");
        exit;
    }
}

// Отправка письма с кодом верификации на почту админа
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';

// Создание объекта PHPMailer
$mail = new PHPMailer\PHPMailer\PHPMailer();

// Настройка параметров SMTP-сервера
$mail->isSMTP();
$mail->Host = 'smtp.mail.com';  // Замените на адрес вашего SMTP-сервера
$mail->SMTPAuth = true;
$mail->Username = 'enot_beceljiak@mail.ru';  // Замените на вашу электронную почту
$mail->Password = 'e5mguvYnwk0BsKXNmj73';  // Замените на ваш пароль от электронной почты
$mail->SMTPSecure = 'ssl';
$mail->Port = 25;  // Замените на порт вашего SMTP-сервера (обычно 587)

// Настройка параметров письма
$mail->setFrom('enot_beceljiak@mail.ru', 'Админ');  // Замените на вашу электронную почту и имя
$mail->addAddress($email);  // Замените на адрес электронной почты админа
$mail->Subject = 'Код верификации';  // Заголовок письма
$mail->Body = 'Ваш код верификации: 653780';  // Тело письма с кодом верификации

// Отправка письма
if ($mail->send()) {
    // Письмо успешно отправлено, выполните необходимые действия
    // Например, показать сообщение о необходимости ввести код верификации
    $verificationMessage = 'Письмо с кодом верификации отправлено на вашу электронную почту.';
} else {
    // Ошибка при отправке письма, выполните необходимые действия
    // Например, показать сообщение об ошибке
    $errorMessage = 'Ошибка при отправке письма: ' . $mail->ErrorInfo;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Верификация админа</title>
    <link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
    <div class="verification-container">
        <h1>Верификация админа</h1>
        <?php if (isset($verificationMessage)) : ?>
            <p class="verification-message"><?php echo $verificationMessage; ?></p>
        <?php endif; ?>
        <?php if (isset($errorMessage)) : ?>
            <p class="error-message"><?php echo $errorMessage; ?></p>
        <?php endif; ?>
        <?php if (!isset($verificationMessage)) : ?>
            <p>На вашу электронную почту было отправлено письмо с кодом верификации. Введите код ниже:</p>
            <?php if (isset($_GET['error']) && $_GET['error'] === 'invalid') : ?>
                <p class="error-message">Неправильный код верификации. Пожалуйста, попробуйте снова.</p>
            <?php endif; ?>
            <form method="POST" action="admin_verify.php?email=<?php echo urlencode($email); ?>">
                <input type="text" name="verification_code" placeholder="Введите код верификации" required>
                <button type="submit">Верифицировать</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
