<?php
// admin_edit_news.php

include 'admin_header.php';

// Ваш код для редактирования новости в таблице "news" базы данных

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получите данные формы
    $newsId = $_POST['news_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];

    // Ваш код для обновления данных новости в таблице "news" базы данных

    // Перенаправление на страницу новостей
    header("Location: admin_news.php");
    exit;
}

// Получите данные новости для предварительного заполнения формы
$newsId = $_GET['news_id'];

// Ваш код для получения данных новости из таблицы "news" базы данных

?>

<!-- Форма для редактирования новости -->
<form method="POST" action="">
    <input type="hidden" name="news_id" value="<?php echo $newsId; ?>">

    <label for="title">Title:</label>
    <input type="text" name="title" value="<?php echo $title; ?>" required><br>

    <label for="description">Description:</label>
    <textarea name="description" required><?php echo $description; ?></textarea><br>

    <button type="submit">Update News</button>
</form>

<?php include 'admin_footer.php'; ?>
