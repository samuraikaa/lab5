<?php
// admin_edit_agent.php

include 'admin_header.php';

// Ваш код для редактирования агента в таблице "agents" базы данных

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получите данные формы
    $agentId = $_POST['agent_id'];
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $description = $_POST['description'];

    // Ваш код для обновления данных агента в таблице "agents" базы данных

    // Перенаправление на страницу агентов
    header("Location: admin_agents.php");
    exit;
}

// Получите данные агента для предварительного заполнения формы
$agentId = $_GET['agent_id'];

// Ваш код для получения данных агента из таблицы "agents" базы данных

?>

<!-- Форма для редактирования агента -->
<form method="POST" action="">
    <input type="hidden" name="agent_id" value="<?php echo $agentId; ?>">

    <label for="first_name">First Name:</label>
    <input type="text" name="first_name" value="<?php echo $firstName; ?>" required><br>

    <label for="last_name">Last Name:</label>
    <input type="text" name="last_name" value="<?php echo $lastName; ?>" required><br>

    <label for="description">Description:</label>
    <textarea name="description" required><?php echo $description; ?></textarea><br>

    <button type="submit">Update Agent</button>
</form>

<?php include 'admin_footer.php'; ?>
