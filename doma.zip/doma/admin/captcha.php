<?php
session_start();

// Генерация случайного кода капчи
$captchaCode = substr(md5(uniqid()), 0, 6);

// Сохранение кода капчи в сессии
$_SESSION['captcha_code'] = $captchaCode;

// Создание изображения капчи
$image = imagecreatetruecolor(100, 40);

// Установка цвета фона
$bgColor = imagecolorallocate($image, 255, 255, 255);
imagefill($image, 0, 0, $bgColor);

// Установка цвета текста
$textColor = imagecolorallocate($image, 0, 0, 0);

// Нанесение кода капчи на изображение
imagestring($image, 5, 20, 10, $captchaCode, $textColor);

// Установка заголовка для вывода изображения
header('Content-type: image/png');

// Вывод изображения капчи
imagepng($image);

// Освобождение памяти
imagedestroy($image);
?>
