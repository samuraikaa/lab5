<?php
// admin_index.php

include 'admin_header.php';

// Ваш код для главной страницы админ-панели

?>

<!-- HTML-разметка главной страницы -->
<h1>Welcome to the Admin Panel</h1>
<p>This is the main page of the admin panel. You can navigate to different sections using the sidebar.</p>

<?php include 'admin_footer.php'; ?>
