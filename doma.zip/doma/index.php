<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="author" content="Untree.co">
	<link rel="shortcut icon" href="favicon.png">

	<meta name="description" content="" />
	<meta name="keywords" content="bootstrap, bootstrap5" />
	
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">


	<link rel="stylesheet" href="fonts/icomoon/style.css">
	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

	<link rel="stylesheet" href="css/tiny-slider.css">
	<link rel="stylesheet" href="css/aos.css">
	<link rel="stylesheet" href="css/style.css">

	<title>Luxuria Estates</title>
</head>
<body>

	<div class="site-mobile-menu site-navbar-target">
		<div class="site-mobile-menu-header">
			<div class="site-mobile-menu-close">
				<span class="icofont-close js-menu-toggle"></span>
			</div>
		</div>
		<div class="site-mobile-menu-body"></div>
	</div>

	<nav class="site-nav">
		<div class="container">
			<div class="menu-bg-wrap">
				<div class="site-navigation">
					<a href="index.html" class="logo-luxuria m-0 float-start"><img src="images/Asset 3.png" alt=""></a>
					<ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu float-end">
						<li class="active"><a href="index.php">Главная</a></li>
						<li><a href="properties.php">Купить</a></li>
						<li><a href="properties_arenda.php">Арендовать</a></li>
						<li><a href="services.php">Новость</a></li>
						<li><a href="about.php">О нас</a></li>
						<li><a href="contact.php">Связаться с нами</a></li>
					</ul>
					<a href="#" class="burger light me-auto float-end mt-1 site-menu-toggle js-menu-toggle d-inline-block d-lg-none" data-toggle="collapse" data-target="#main-navbar">
						<span></span>
					</a>
				</div>
			</div>
		</div>
	</nav>
	<div class="hero">
		<div class="hero-slide">
			<div class="img overlay" style="background-image: url('images/hero_bg_3.jpg')"></div>
			<div class="img overlay" style="background-image: url('images/hero_bg_2.jpg')"></div>
			<div class="img overlay" style="background-image: url('images/hero_bg_1.jpg')"></div>
		</div>

		<div class="container">
			<div class="row justify-content-center align-items-center">
				<div class="col-lg-9 text-center">
					<h1 class="heading">Найдите дом своей мечты</h1>
					<form action="#" class="narrow-w form-search d-flex align-items-stretch mb-3" data-aos-delay="200">
						<input type="text" class="form-control px-4" placeholder="Найдите дом своей мечты">
						<button type="submit" class="btn btn-primary">Поиск</button>
					</form>
				</div>
			</div>
		</div>
	</div>


	<div class="section">
		<div class="container">
			<div class="row mb-5 align-items-center">
				<div class="col-lg-6">
					<h2 class="font-weight-bold text-primary heading">Популярные дома</h2>
				</div>
				<div class="col-lg-6 text-lg-end">
					<p><a href="#" target="_blank" class="btn btn-primary text-white py-3 px-4">Просмотреть все объекты недвижимости</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-12">
					<div class="property-slider-wrap">
						<div class="property-slider">
							<div class="property-item">
								<a href="property-single.html" class="img">
									<img src="images/img_1.jpg" alt="Image" class="img-fluid">
								</a>
								<div class="property-content">
									<div class="price mb-2"><span>AED 1,291,000</span></div>
									<div>
										<span class="d-block mb-2 text-black-50">5232 Дубаи, пр. 21BC</span>
										<span class="city d-block mb-3">Думаи, ОАЭ</span>
										<div class="specs d-flex mb-4">
											<span class="d-block d-flex align-items-center me-3">
												<span class="icon-bed me-2"></span>
												<span class="caption">2 кровати</span>
											</span>
											<span class="d-block d-flex align-items-center">
												<span class="icon-bath me-2"></span>
												<span class="caption">2 ванны</span>
											</span>
										</div>
										<a href="property-single.html" class="btn btn-primary py-2 px-3">Посмотреть подробности</a>
									</div>
								</div>
							</div> <!-- .item -->
							<div class="property-item">
								<a href="property-single.html" class="img">
									<img src="images/img_2.jpg" alt="Image" class="img-fluid">
								</a>
								<div class="property-content">
									<div class="price mb-2"><span>AED 1,291,000</span></div>
									<div>
										<span class="d-block mb-2 text-black-50">5232 Дубаи, пр. 21BC</span>
										<span class="city d-block mb-3">Думаи, ОАЭ</span>
										<div class="specs d-flex mb-4">
											<span class="d-block d-flex align-items-center me-3">
												<span class="icon-bed me-2"></span>
												<span class="caption">2 кровати</span>
											</span>
											<span class="d-block d-flex align-items-center">
												<span class="icon-bath me-2"></span>
												<span class="caption">2 ванны</span>
											</span>
										</div>
										<a href="property-single.html" class="btn btn-primary py-2 px-3">Посмотреть подробности</a>
									</div>
								</div>
							</div> <!-- .item -->

							<div class="property-item">

								<a href="property-single.html" class="img">
									<img src="images/img_3.jpg" alt="Image" class="img-fluid">
								</a>

								<div class="property-content">
									<div class="price mb-2"><span>AED 1,291,000</span></div>
									<div>
										<span class="d-block mb-2 text-black-50">5232 Дубаи, пр. 21BC</span>
										<span class="city d-block mb-3">Думаи, ОАЭ</span>
										<div class="specs d-flex mb-4">
											<span class="d-block d-flex align-items-center me-3">
												<span class="icon-bed me-2"></span>
												<span class="caption">2 кровати</span>
											</span>
											<span class="d-block d-flex align-items-center">
												<span class="icon-bath me-2"></span>
												<span class="caption">2 ванны</span>
											</span>
										</div>
										<a href="property-single.html" class="btn btn-primary py-2 px-3">Посмотреть подробности</a>
									</div>
								</div>
							</div> <!-- .item -->

							<div class="property-item">

								<a href="property-single.html" class="img">
									<img src="images/img_4.jpg" alt="Image" class="img-fluid">
								</a>

								<div class="property-content">
									<div class="price mb-2"><span>AED 1,291,000</span></div>
									<div>
										<span class="d-block mb-2 text-black-50">5232 Дубаи, пр. 21BC</span>
										<span class="city d-block mb-3">Думаи, ОАЭ</span>
										<div class="specs d-flex mb-4">
											<span class="d-block d-flex align-items-center me-3">
												<span class="icon-bed me-2"></span>
												<span class="caption">2 кровати</span>
											</span>
											<span class="d-block d-flex align-items-center">
												<span class="icon-bath me-2"></span>
												<span class="caption">2 ванны</span>
											</span>
										</div>
										<a href="property-single.html" class="btn btn-primary py-2 px-3">Посмотреть подробности</a>
									</div>
								</div>
							</div> <!-- .item -->

							<div class="property-item">

								<a href="property-single.html" class="img">
									<img src="images/img_5.jpg" alt="Image" class="img-fluid">
								</a>

								<div class="property-content">
									<div class="price mb-2"><span>AED 1,291,000</span></div>
									<div>
										<span class="d-block mb-2 text-black-50">5232 Дубаи, пр. 21BC</span>
										<span class="city d-block mb-3">Думаи, ОАЭ</span>
										<div class="specs d-flex mb-4">
											<span class="d-block d-flex align-items-center me-3">
												<span class="icon-bed me-2"></span>
												<span class="caption">2 кровати</span>
											</span>
											<span class="d-block d-flex align-items-center">
												<span class="icon-bath me-2"></span>
												<span class="caption">2 ванны</span>
											</span>
										</div>
										<a href="property-single.html" class="btn btn-primary py-2 јx-3">Посмотреть подробности</a>
									</div>
								</div>
							</div> <!-- .item -->

							<div class="property-item">

								<a href="property-single.html" class="img">
									<img src="images/img_6.jpg" alt="Image" class="img-fluid">
								</a>

								<div class="property-content">
									<div class="price mb-2"><span>AED 1,291,000</span></div>
									<div>
										<span class="d-block mb-2 text-black-50">5232 Дубаи, пр. 21BC</span>
										<span class="city d-block mb-3">Думаи, ОАЭ</span>
										<div class="specs d-flex mb-4">
											<span class="d-block d-flex align-items-center me-3">
												<span class="icon-bed me-2"></span>
												<span class="caption">2 кровати</span>
											</span>
											<span class="d-block d-flex align-items-center">
												<span class="icon-bath me-2"></span>
												<span class="caption">2 ванны</span>
											</span>
										</div>
										<a href="property-single.html" class="btn btn-primary py-2 px-3">Посмотреть подробности</a>
									</div>
								</div>
							</div> <!-- .item -->

							<div class="property-item">

								<a href="property-single.html" class="img">
									<img src="images/img_7.jpg" alt="Image" class="img-fluid">
								</a>

								<div class="property-content">
									<div class="price mb-2"><span>AED 1,291,000</span></div>
									<div>
										<span class="d-block mb-2 text-black-50">5232 Дубаи, пр. 21BC</span>
										<span class="city d-block mb-3">Думаи, ОАЭ</span>
										<div class="specs d-flex mb-4">
											<span class="d-block d-flex align-items-center me-3">
												<span class="icon-bed me-2"></span>
												<span class="caption">2 кровати</span>
											</span>
											<span class="d-block d-flex align-items-center">
												<span class="icon-bath me-2"></span>
												<span class="caption">2 ванны</span>
											</span>
										</div>
										<a href="property-single.html" class="btn btn-primary py-2 px-3">Посмотреть подробности</a>
									</div>
								</div>
							</div> <!-- .item -->

							<div class="property-item">

								<a href="property-single.html" class="img">
									<img src="images/img_8.jpg" alt="Image" class="img-fluid">
								</a>

								<div class="property-content">
									<div class="price mb-2"><span>AED 1,291,000</span></div>
									<div>
										<span class="d-block mb-2 text-black-50">5232 Дубаи, пр. 21BC</span>
										<span class="city d-block mb-3">Думаи, ОАЭ</span>
										<div class="specs d-flex mb-4">
											<span class="d-block d-flex align-items-center me-3">
												<span class="icon-bed me-2"></span>
												<span class="caption">2 кровати</span>
											</span>
											<span class="d-block d-flex align-items-center">
												<span class="icon-bath me-2"></span>
												<span class="caption">2 ванны</span>
											</span>
										</div>
										<a href="property-single.html" class="btn btn-primary py-2 px-3">Посмотреть подробности</a>
									</div>
								</div>
							</div> <!-- .item -->

							<div class="property-item">

								<a href="property-single.html" class="img">
									<img src="images/img_1.jpg" alt="Image" class="img-fluid">
								</a>

								<div class="property-content">
									<div class="price mb-2"><span>AED 1,291,000</span></div>
									<div>
										<span class="d-block mb-2 text-black-50">5232 Дубаи, пр. 21BC</span>
										<span class="city d-block mb-3">Думаи, ОАЭ</span>
										<div class="specs d-flex mb-4">
											<span class="d-block d-flex align-items-center me-3">
												<span class="icon-bed me-2"></span>
												<span class="caption">2 кровати</span>
											</span>
											<span class="d-block d-flex align-items-center">
												<span class="icon-bath me-2"></span>
												<span class="caption">2 ванны</span>
											</span>
										</div>
										<a href="property-single.html" class="btn btn-primary py-2 px-3">Посмотреть подробности</a>
									</div>
								</div>
							</div> <!-- .item -->
						</div>
						<div id="property-nav" class="controls" tabindex="0" aria-label="Carousel Navigation">
							<span class="prev" data-controls="prev" aria-controls="property" tabindex="-1">Предыдущее</span>
							<span class="next" data-controls="next" aria-controls="property" tabindex="-1">Следующее</span>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>

	<section class="features-1">
		<div class="container">
			<div class="row">
				<div class="col-6 col-lg-3" data-aos-delay="300">
					<div class="box-feature">
						<span class="flaticon-house"></span>
						<h3 class="mb-3">Наш главный плюс</h3>
						<p>Самое крупное и надежное агенство по продаже недвижимости.</p>
					</div>
				</div>
				<div class="col-6 col-lg-3" data-aos-delay="500">
					<div class="box-feature">
						<span class="flaticon-building"></span>
						<h3 class="mb-3">Покупка и аренда недвижимости</h3>
						<p>Покупка/Аренда: дома для проживания и деловых поездок.</p>
					</div>
				</div>
				<div class="col-6 col-lg-3"  data-aos-delay="400">
					<div class="box-feature">
						<span class="flaticon-house-3"></span>
						<h3 class="mb-3">Агент по недвижимости</h3>
						<p>Наши агенты по недвижимости помогут вам с выбором и ознакомят со всей недвижимостью.</p>
					</div>
				</div>
				<div class="col-6 col-lg-3" data-aos-delay="600">
					<div class="box-feature">
						<span class="flaticon-house-1"></span>
						<h3 class="mb-3">Продажа и сдача в аренду недвижимости</h3>
						<p>Полная консультация и создание объявления.</p>
					</div>
				</div>	
			</div>
		</div>
	</section>



	<div class="section sec-testimonials">
		<div class="container">
			<div class="row mb-5 align-items-center">
				<div class="col-md-6">
					<h2 class="font-weight-bold heading text-primary mb-4 mb-md-0">Клиент говорит</h2>
				</div>
				<div class="col-md-6 text-md-end">
					<div id="testimonial-nav">
						<span class="prev" data-controls="prev">Предыдущее</span>
						
						<span class="next" data-controls="next">Следующее</span>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-lg-4">
					
				</div>
			</div>
			<div class="testimonial-slider-wrap">
				<div class="testimonial-slider">
					<div class="item">
						<div class="testimonial">
							<img src="images/person_1-min.jpg" alt="Image" class="img-fluid rounded-circle w-25 mb-4">
							<div class="rate">
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
							</div>
							<h3 class="h5 text-primary mb-4">Стефан Магис</h3>
							<blockquote>
								<p>Максимальный восторг! Я хотел узнать больше о рынке недвижимости Дубая. Бог послал мне уникальную интеллигентную девушку, Юлию Кравченко, обладающую, несомненно, высочайшей компетенцией в этом деле. Очень доволен квалифицированным изложением темы. Я и мои партнеры рассчитываем на сотрудничество с Юлией для реализации наших планов по покупке недвижимости в Дубае. Спасибо, Иван!</p>
							</blockquote>
							<p class="text-black-50">Заказчик</p>
						</div>
					</div>

					<div class="item">
						<div class="testimonial">
							<img src="images/person_2-min.jpg" alt="Image" class="img-fluid rounded-circle w-25 mb-4">
							<div class="rate">
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
							</div>
							<h3 class="h5 text-primary mb-4">Джуниор Скотти</h3>
							<blockquote>
								<p>Наш агент Надя Чамор – фантастический и надежный человек, очень знающий и профессиональный. Она помогла нам с нашим первым бизнесом в Дубае.</p>
							</blockquote>
							<p class="text-black-50">Заказчик</p>
						</div>
					</div>

					<div class="item">
						<div class="testimonial">
							<img src="images/person_3-min.jpg" alt="Image" class="img-fluid rounded-circle w-25 mb-4">
							<div class="rate">
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
							</div>
							<h3 class="h5 text-primary mb-4">Натали Сивак</h3>
							<blockquote>
								<p>Наш агент по недвижимости – Куликов Кирилл, мы очень довольны его работой и хотелось бы отметить его подход к клиенту. Начиная с первого разговора, где мне задали все необходимые вопросы, чтобы найти что-то именно под нас, заканчивая подписанием контракта с застройщиком. Контакт оцениваю на 10 из 10. Не знаю сколько Кирилл спит, но на связи она всегда. Человек ответственный, обязательный, ненавязчивый и слушающий. Так что спасибо!</p>
							</blockquote>
							<p class="text-black-50">Заказчик</p>
						</div>
					</div>

					<div class="item">
						<div class="testimonial">
							<img src="images/person_4-min.jpg" alt="Image" class="img-fluid rounded-circle w-25 mb-4">
							<div class="rate">
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
								<span class="icon-star text-warning"></span>
							</div>
							<h3 class="h5 text-primary mb-4">Джузеппе Иорио</h3>
							<blockquote>
								<p>Владислав тот человек, с которым можно поговорить. Он любит свою работу и действительно готов ответить на любой ваш вопрос. Люблю вести с ним дела, и, надеюсь, вместе мы сделаем еще гораздо больше.</p>
							</blockquote>
							<p class="text-black-50">Заказчик</p>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>


	<div class="section section-4 bg-light">
		<div class="container">
			<div class="row justify-content-center  text-center mb-5">
				<div class="col-lg-5">
					<h2 class="font-weight-bold heading text-primary mb-4">Давайте найдем дом, которыйидеально подойдет для вас</h2>
					<p class="text-black-50">Мы понимаем, что современные люди стремятся к максимальному комфорту. Гармоничная среда, общение с профессионалами, точная и своевременная информация, надежные и удобные технологические решения, позволяющие экономить важные для них ресурсы.</p>
				</div>
			</div>
			<div class="row justify-content-between mb-5">
				<div class="col-lg-7 mb-5 mb-lg-0 order-lg-2">
					<div class="img-about dots">
						<img src="images/hero_bg_3.jpg" alt="Image" class="img-fluid">
					</div>
				</div>
				<div class="col-lg-4">
					<div class="d-flex feature-h">
						<span class="wrap-icon me-3">
							<span class="icon-home2"></span>
						</span>
						<div class="feature-text">
							<h3 class="heading">2М Сделок</h3>
							<p class="text-black-50">Самые надежные 2 миллиона сделок. Наш гарант.</p>
						</div>
					</div>
					<div class="d-flex feature-h">
						<span class="wrap-icon me-3">
							<span class="icon-person"></span>
						</span>
						<div class="feature-text">
							<h3 class="heading">Лучшие агенты по рейтингу</h3>
							<p class="text-black-50">У каждого агента опыт работы минимум 2 года.</p>
						</div>
					</div>
					<div class="d-flex feature-h">
						<span class="wrap-icon me-3">
							<span class="icon-security"></span>
						</span>
						<div class="feature-text">
							<h3 class="heading">Законная недвижимость</h3>
							<p class="text-black-50">Все сделки совершаются на законных основаниях ОАЭ.</p>
						</div>
					</div>
				</div>
			</div>
			<div class="row section-counter mt-5">
				<div class="col-6 col-sm-6 col-md-6 col-lg-3" data-aos-delay="300">
					<div class="counter-wrap mb-5 mb-lg-0">
						<span class="number"><span class="text-primary">3298</span></span>
						<span class="caption text-black-50">единиц купленной недвижимости</span>
					</div>
				</div>
				<div class="col-6 col-sm-6 col-md-6 col-lg-3" data-aos-delay="400">
					<div class="counter-wrap mb-5 mb-lg-0">
						<span class="number"><span class="text-primary">2181</span></span>
						<span class="caption text-black-50">количество проданных объектов</span>
					</div>
				</div>
				<div class="col-6 col-sm-6 col-md-6 col-lg-3" data-aos-delay="500">
					<div class="counter-wrap mb-5 mb-lg-0">
						<span class="number"><span class="text-primary">9316</span></span>
						<span class="caption text-black-50">всех объектов</span>
					</div>
				</div>
				<div class="col-6 col-sm-6 col-md-6 col-lg-3" data-aos-delay="600">
					<div class="counter-wrap mb-5 mb-lg-0">
						<span class="number"><span class="text-primary">7191</span></span>
						<span class="caption text-black-50">агентов</span>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="section section-5 bg-light">
		<div class="container">
			<div class="row justify-content-center  text-center mb-5">
				<div class="col-lg-6 mb-5">
					<h2 class="font-weight-bold heading text-primary mb-4">Наши агенты</h2>
					<p class="text-black-50">Наша команда имеет в своем распоряжении более 30 языков. Мы гарантируем, что у нас вы найдете квалифицированного агента для сотрудничества.</p>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6 col-md-6 col-lg-4 mb-5 mb-lg-0">
					<div class="h-100 person">

						<img src="images/person_1-min.jpg" alt="Image"
						class="img-fluid">

						<div class="person-contents">
							<h2 class="mb-0"><a href="#">Дударь Иван</a></h2>
							<span class="meta d-block mb-3">Агент по недвижисомти</span>
							<p>Доктор наук в области международного права, великолепный переговорщик и дипломат, Дмитрий умеет мягко, но уверенно отстаивать интересы клиентов.</p>

							<ul class="social list-unstyled list-inline dark-hover">
								<li class="list-inline-item"><a href="#"><span class="icon-twitter"></span></a></li>
								<li class="list-inline-item"><a href="#"><span class="icon-facebook"></span></a></li>
								<li class="list-inline-item"><a href="#"><span class="icon-linkedin"></span></a></li>
								<li class="list-inline-item"><a href="#"><span class="icon-instagram"></span></a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-sm-6 col-md-6 col-lg-4 mb-5 mb-lg-0">
					<div class="h-100 person">

						<img src="images/person_2-min.jpg" alt="Image"
						class="img-fluid">

						<div class="person-contents">
							<h2 class="mb-0"><a href="#">Кулликов Кирилл</a></h2>
							<span class="meta d-block mb-3">Агент по недвижисомти</span>
							<p>На протяжении многих лет он успешно работал с ведущими застройщиками Дубая, компаниями Dubai Properties и Select Group, а также с Benchmark Lebanon в Ливане, в результате чего были совершены сделки купли-продажи на сумму более 1 млрд $.</p>

							<ul class="social list-unstyled list-inline dark-hover">
								<li class="list-inline-item"><a href="#"><span class="icon-twitter"></span></a></li>
								<li class="list-inline-item"><a href="#"><span class="icon-facebook"></span></a></li>
								<li class="list-inline-item"><a href="#"><span class="icon-linkedin"></span></a></li>
								<li class="list-inline-item"><a href="#"><span class="icon-instagram"></span></a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-sm-6 col-md-6 col-lg-4 mb-5 mb-lg-0">
					<div class="h-100 person">

						<img src="images/person_3-min.jpg" alt="Image"
						class="img-fluid">

						<div class="person-contents">
							<h2 class="mb-0"><a href="#">Велешев Владислав</a></h2>
							<span class="meta d-block mb-3">Real Estate Agent</span>
							<p>Велешев Владислав родился в Кишиневе, где получил высшее образование в области экономического права. Три года жил и работал в Москве.</p>

							<ul class="social list-unstyled list-inline dark-hover">
								<li class="list-inline-item"><a href="#"><span class="icon-twitter"></span></a></li>
								<li class="list-inline-item"><a href="#"><span class="icon-facebook"></span></a></li>
								<li class="list-inline-item"><a href="#"><span class="icon-linkedin"></span></a></li>
								<li class="list-inline-item"><a href="#"><span class="icon-instagram"></span></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="site-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-4">
					<div class="widget">
						<h3>Контакты</h3>
						<address>Адрес: 123317, г. Москва, ул. Пресненская набережная, 8с1</address>
						<ul class="list-unstyled links">
							<li><a href="tel://11234567890">+7(900)-888-99-88</a></li>
							<li><a href="tel://97142222222">+(971) 4-222 2222</a></li>
							<li><a href="mailto:info@mydomain.com">info@luxuriaestates.com</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="widget">
						<h3>Страницы</h3>
						<ul class="list-unstyled float-start links">
							<li><a href="index.html">Главная</a></li>
							<li><a href="properties.html">Купить</a></li>
							<li><a href="properties_arenda.html">Арендовать</a></li>
							<li><a href="services.html">Новости</a></li>
							<li><a href="about.html">О нас</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="widget">
						<h3>Ссылки</h3>
						<ul class="list-unstyled links">
							<li><a href="contact.html">Связаться с нами</a></li>
						</ul>
						<ul class="list-unstyled social">
							<li><a href="#"><span class="icon-instagram"></span></a></li>
							<li><a href="#"><span class="icon-twitter"></span></a></li>
							<li><a href="#"><span class="icon-facebook"></span></a></li>
							<li><a href="#"><span class="icon-linkedin"></span></a></li>
							<li><a href="#"><span class="icon-pinterest"></span></a></li>
							<li><a href="#"><span class="icon-dribbble"></span></a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="row mt-5">
				<div class="col-12 text-center">
            <p>Luxuria Estates&copy;<script>document.write(new Date().getFullYear());</script>. Все Права Защищены
            </p>

          </div>
        </div>
      </div>
    </div> 
	<div id="overlayer"></div>
    <div class="loader">
    	<div class="spinner-border" role="status">
    		<span class="visually-hidden">Loading...</span>
    	</div>
    </div>

    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/tiny-slider.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/navbar.js"></script>
    <script src="js/counter.js"></script>
    <script src="js/custom.js"></script>
  </body>
  </html>
