<form action="login.php" method="POST">
  <label for="username">Логин:</label>
  <input type="text" id="username" name="username" required>

  <label for="password">Пароль:</label>
  <input type="password" id="password" name="password" required>

  <input type="submit" value="Войти">
</form>
