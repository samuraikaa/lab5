<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="author" content="Untree.co">
	<link rel="shortcut icon" href="favicon.png">
	<meta name="description" content="" />
	<meta name="keywords" content="bootstrap, bootstrap5" />
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="fonts/icomoon/style.css">
	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
	<link rel="stylesheet" href="css/tiny-slider.css">
	<link rel="stylesheet" href="css/aos.css">
	<link rel="stylesheet" href="css/style.css">
	<title>Luxuria Estates</title>
</head>
<body>
	<div class="site-mobile-menu site-navbar-target">
		<div class="site-mobile-menu-header">
			<div class="site-mobile-menu-close">
				<span class="icofont-close js-menu-toggle"></span>
			</div>
		</div>
		<div class="site-mobile-menu-body"></div>
	</div>
	<nav class="site-nav">
		<div class="container">
			<div class="menu-bg-wrap">
				<div class="site-navigation">
					<a href="index.html" class="logo-luxuria m-0 float-start"><img src="/images/Asset 3.png" alt=""></a>
					<ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu float-end">
						<li><a href="index.html">Главная</a></li>
						<li class="active"><a href="properties.html">Купить</a></li>
						<li><a href="properties_arenda.html">Арендовать</a></li>
						<li><a href="services.html">Новость</a></li>
						<li><a href="about.html">О нас</a></li>
						<li><a href="contact.html">Связаться с нами</a></li>
					</ul>
					<a href="#" class="burger light me-auto float-end mt-1 site-menu-toggle js-menu-toggle d-inline-block d-lg-none" data-toggle="collapse" data-target="#main-navbar">
						<span></span>
					</a>
				</div>
			</div>
		</div>
	</nav>
	<div class="hero page-inner overlay" style="background-image: url('images/hero_bg_3.jpg');">
		<div class="container">
			<div class="row justify-content-center align-items-center">
				<div class="col-lg-9 text-center mt-5">
					<h1 class="heading">5232 Дубаи, пр. 21BC</h1>
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb text-center justify-content-center">
							<li class="breadcrumb-item "><a href="index.html">Главная</a></li>
							<li class="breadcrumb-item "><a href="properties.html">Купить</a></li>
							<li class="breadcrumb-item active text-white-50" aria-current="page">5232 Дубаи, пр. 21BC</li>
						</ol>
					</nav>
				</div>
			</div>
		</div>
	</div>
	<div class="section">
		<div class="container">
			<div class="row justify-content-between">
				<div class="col-lg-7">
					<div class="img-property-slide-wrap">
						<div class="img-property-slide">
							<img src="images/img_1.jpg" alt="Image" class="img-fluid">
							<img src="images/img_2.jpg" alt="Image" class="img-fluid">
							<img src="images/img_3.jpg" alt="Image" class="img-fluid">
						</div>
					</div>
				</div>
				<div class="col-lg-4">
					<h2 class="heading text-primary">5232 Дубаи, пр. 21BC</h2>
					<p class="meta">Думаи, ОАЭ</p>
					<p class="text-black-50">Luxuria Estates рада представить эту недвижимость в Nad Al Sheba Gardens.</p>
					<p class="text-black-50">Современная недвижимость со всеми удобствами для комфортного проживания. Расположение проекта предлагает хорошо развитую инфраструктуру. Жители могут найти такие удобства как: охрана, встроенные шкафы, кондиционеры, балкон, детская площадка, встроенная кухонная техника и развлекательные заведения в непосредственной близости.</p>
					
					<div class="d-block agent-box p-5">
						<div class="img mb-4">
							<img src="images/person_2-min.jpg" alt="Image" class="img-fluid">
						</div>
						<div class="text">
							<h3 class="mb-0">Кулликов Кирилл</h3>
							<div class="meta mb-3">Агент по недвижисомти</div>
							<p>Помогу вам разобраться с данной недвижимостью.</p>
							<ul class="list-unstyled social dark-hover d-flex">
								<li class="me-1"><a href="#"><span class="icon-instagram"></span></a></li>
								<li class="me-1"><a href="#"><span class="icon-twitter"></span></a></li>
								<li class="me-1"><a href="#"><span class="icon-facebook"></span></a></li>
								<li class="me-1"><a href="#"><span class="icon-linkedin"></span></a></li>

							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="site-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-4">
					<div class="widget">
						<h3>Контакты</h3>
						<address>Адрес: 123317, г. Москва, ул. Пресненская набережная, 8с1</address>
						<ul class="list-unstyled links">
							<li><a href="tel://11234567890">+7(900)-888-99-88</a></li>
							<li><a href="tel://97142222222">+(971) 4-222 2222</a></li>
							<li><a href="mailto:info@mydomain.com">info@luxuriaestates.com</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="widget">
						<h3>Страницы</h3>
						<ul class="list-unstyled float-start links">
							<li><a href="index.html">Главная</a></li>
							<li><a href="properties.html">Купить</a></li>
							<li><a href="properties_arenda.html">Арендовать</a></li>
							<li><a href="services.html">Новости</a></li>
							<li><a href="about.html">О нас</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="widget">
						<h3>Ссылки</h3>
						<ul class="list-unstyled links">
							<li><a href="contact.html">Связаться с нами</a></li>
						</ul>
						<ul class="list-unstyled social">
							<li><a href="#"><span class="icon-instagram"></span></a></li>
							<li><a href="#"><span class="icon-twitter"></span></a></li>
							<li><a href="#"><span class="icon-facebook"></span></a></li>
							<li><a href="#"><span class="icon-linkedin"></span></a></li>
							<li><a href="#"><span class="icon-pinterest"></span></a></li>
							<li><a href="#"><span class="icon-dribbble"></span></a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="row mt-5">
				<div class="col-12 text-center">
            <p>Luxuria Estates&copy;<script>document.write(new Date().getFullYear());</script>. Все Права Защищены
            </p>
          </div>
        </div>
      </div>
    </div> 
    <div id="overlayer"></div>
    <div class="loader">
    	<div class="spinner-border" role="status">
    		<span class="visually-hidden">Loading...</span>
    	</div>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/tiny-slider.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/navbar.js"></script>
    <script src="js/counter.js"></script>
    <script src="js/custom.js"></script>
  </body>
  </html>
