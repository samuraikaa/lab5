<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="author" content="Untree.co">
	<link rel="shortcut icon" href="favicon.png">
	<meta name="description" content="" />
	<meta name="keywords" content="bootstrap, bootstrap5" />
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="fonts/icomoon/style.css">
	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
	<link rel="stylesheet" href="css/tiny-slider.css">
	<link rel="stylesheet" href="css/aos.css">
	<link rel="stylesheet" href="css/style.css">
	<title>Luxuria Estates</title>
</head>
<body>
	<div class="site-mobile-menu site-navbar-target">
		<div class="site-mobile-menu-header">
			<div class="site-mobile-menu-close">
				<span class="icofont-close js-menu-toggle"></span>
			</div>
		</div>
		<div class="site-mobile-menu-body"></div>
	</div>

	<nav class="site-nav">
		<div class="container">
			<div class="menu-bg-wrap">
				<div class="site-navigation">
					<a href="index.html" class="logo-luxuria m-0 float-start"><img src="/images/Asset 3.png" alt=""></a>
					<ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu float-end">
						<li><a href="index.html">Главная</a></li>
						<li><a href="properties.html">Купить</a></li>
						<li><a href="properties_arenda.html">Арендовать</a></li>
						<li><a href="services.html">Новость</a></li>
						<li><a href="about.html">О нас</a></li>
						<li class="active"><a href="contact.html">Связаться с нами</a></li>
					</ul>
					<a href="#" class="burger light me-auto float-end mt-1 site-menu-toggle js-menu-toggle d-inline-block d-lg-none" data-toggle="collapse" data-target="#main-navbar">
						<span></span>
					</a>
				</div>
			</div>
		</div>
	</nav>
	<div class="hero page-inner overlay" style="background-image: url('images/hero_bg_1.jpg');">
		<div class="container">
			<div class="row justify-content-center align-items-center">
				<div class="col-lg-9 text-center mt-5">
					<h1 class="heading">Связаться с нами</h1>
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb text-center justify-content-center">
							<li class="breadcrumb-item "><a href="index.html">Главная</a></li>
							<li class="breadcrumb-item active text-white-50" aria-current="page">Связаться с нами</li>
						</ol>
					</nav>
				</div>
			</div>
		</div>
	</div>
	<div class="section">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 mb-5 mb-lg-0">
					<div class="contact-info">
						<div class="address mt-2">
							<i class="icon-room"></i>
							<h4 class="mb-2">Расположение:</h4>
							<p>ул. Пресненская набережная, 8с1<br>Москва</p>
						</div>
						<div class="open-hours mt-4">
							<i class="icon-clock-o"></i>
							<h4 class="mb-2">Часы работы:</h4>
							<p>
								Воскресенье-пятница<br>
								c 09:00 до 23:00
							</p>
						</div>
						<div class="email mt-4">
							<i class="icon-envelope"></i>
							<h4 class="mb-2">Электронная почта</h4>
							<p>info@Luxuria.com</p>
						</div>
						<div class="phone mt-4">
							<i class="icon-phone"></i>
							<h4 class="mb-2">Позвоните:</h4>
							<p>+7(900)-888-99-88<br>+(971) 4-222 2222</p>
						</div>
					</div>
				</div>
				<div class="col-lg-8">
					<form action="#">
						<div class="row">
							<div class="col-6 mb-3">
								<input type="text" class="form-control" placeholder="Ваше имя">
							</div>
							<div class="col-6 mb-3">
								<input type="email" class="form-control" placeholder="Ваш  Email">
							</div>
							<div class="col-12 mb-3">
								<input type="text" class="form-control" placeholder="Тема">
							</div>
							<div class="col-12 mb-3">
								<textarea name="" id="" cols="30" rows="7" class="form-control" placeholder="Сообщение"></textarea>
							</div>

							<div class="col-12">
								<input type="submit" value="Отправить сообщение" class="btn btn-primary">
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div> 
	<div class="site-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-4">
					<div class="widget">
						<h3>Контакты</h3>
						<address>Адрес: 123317, г. Москва, ул. Пресненская набережная, 8с1</address>
						<ul class="list-unstyled links">
							<li><a href="tel://11234567890">+7(900)-888-99-88</a></li>
							<li><a href="tel://97142222222">+(971) 4-222 2222</a></li>
							<li><a href="mailto:info@mydomain.com">info@luxuriaestates.com</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="widget">
						<h3>Страницы</h3>
						<ul class="list-unstyled float-start links">
							<li><a href="index.html">Главная</a></li>
							<li><a href="properties.html">Купить</a></li>
							<li><a href="properties_arenda.html">Арендовать</a></li>
							<li><a href="services.html">Новости</a></li>
							<li><a href="about.html">О нас</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="widget">
						<h3>Ссылки</h3>
						<ul class="list-unstyled links">
							<li><a href="contact.html">Связаться с нами</a></li>
						</ul>
						<ul class="list-unstyled social">
							<li><a href="#"><span class="icon-instagram"></span></a></li>
							<li><a href="#"><span class="icon-twitter"></span></a></li>
							<li><a href="#"><span class="icon-facebook"></span></a></li>
							<li><a href="#"><span class="icon-linkedin"></span></a></li>
							<li><a href="#"><span class="icon-pinterest"></span></a></li>
							<li><a href="#"><span class="icon-dribbble"></span></a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="row mt-5">
				<div class="col-12 text-center">
            <p>Luxuria Estates&copy;<script>document.write(new Date().getFullYear());</script>. Все Права Защищены
            </p>
          </div>
        </div>
      </div>
    </div> 
    <div id="overlayer"></div>
    <div class="loader">
    	<div class="spinner-border" role="status">
    		<span class="visually-hidden">Загрузка...</span>
    	</div>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/tiny-slider.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/navbar.js"></script>
    <script src="js/counter.js"></script>
    <script src="js/custom.js"></script>
  </body>
  </html>
