<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="author" content="Untree.co">
	<link rel="shortcut icon" href="favicon.png">
	<meta name="description" content="" />
	<meta name="keywords" content="bootstrap, bootstrap5" />
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="fonts/icomoon/style.css">
	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
	<link rel="stylesheet" href="css/tiny-slider.css">
	<link rel="stylesheet" href="css/aos.css">
	<link rel="stylesheet" href="css/style.css">
	<title>Luxuria Estates</title>
</head>
<body>
	<div class="site-mobile-menu site-navbar-target">
		<div class="site-mobile-menu-header">
			<div class="site-mobile-menu-close">
				<span class="icofont-close js-menu-toggle"></span>
			</div>
		</div>
		<div class="site-mobile-menu-body"></div>
	</div>
	<nav class="site-nav">
		<div class="container">
			<div class="menu-bg-wrap">
				<div class="site-navigation">
					<a href="index.html" class="logo-luxuria m-0 float-start"><img src="images/Asset 3.png" alt=""></a>
					<ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu float-end">
						<li><a href="index.html">Главная</a></li>
						<li><a href="properties.html">Купить</a></li>
						<li><a href="properties_arenda.html">Арендовать</a></li>
						<li class="active"><a href="services.html">Новость</a></li>
						<li><a href="about.html">О нас</a></li>
						<li><a href="contact.html">Связаться с нами</a></li>
					</ul>
					<a href="#" class="burger light me-auto float-end mt-1 site-menu-toggle js-menu-toggle d-inline-block d-lg-none" data-toggle="collapse" data-target="#main-navbar">
						<span></span>
					</a>
				</div>
			</div>
		</div>
	</nav>
	<div class="hero page-inner overlay" style="background-image: url('images/hero_bg_1.jpg');">
		<div class="container">
			<div class="row justify-content-center align-items-center">
				<div class="col-lg-9 text-center mt-5">
					<h1 class="heading">Новости</h1>
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb text-center justify-content-center">
							<li class="breadcrumb-item "><a href="index.html">Главная</a></li>
							<li class="breadcrumb-item active text-white-50" aria-current="page">Новости
							</li>
						</ol>
					</nav>
				</div>
			</div>
		</div>
	</div>
	<div class="section sec-testimonials-ggg">
		<div class="container">
			<div class="justify-content-center-ggg mb-5">
				<div class="d-flex feature-h">
					<span class="wrap-icon me-3">
						<span class="icon-home2"></span>
					</span>
					<div class="feature-text">
						<h3 class="heading">Новость</h3>
						<p class="text-black-50">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
					</div>
				</div>
				<div class="d-flex feature-h">
					<span class="wrap-icon me-3">
						<span class="icon-home2"></span>
					</span>
					<div class="feature-text">
						<h3 class="heading">Новость</h3>
						<p class="text-black-50">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
					</div>
				</div>
				<div class="d-flex feature-h">
					<span class="wrap-icon me-3">
						<span class="icon-home2"></span>
					</span>
					<div class="feature-text">
						<h3 class="heading">Новость</h3>
						<p class="text-black-50">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
					</div>
				</div>
			</div>
			<div class="justify-content-center-ggg mb-5">
				<div class="d-flex feature-h">
					<span class="wrap-icon me-3">
						<span class="icon-home2"></span>
					</span>
					<div class="feature-text">
						<h3 class="heading">Новость</h3>
						<p class="text-black-50">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
					</div>
				</div>
				<div class="d-flex feature-h">
					<span class="wrap-icon me-3">
						<span class="icon-home2"></span>
					</span>
					<div class="feature-text">
						<h3 class="heading">Новость</h3>
						<p class="text-black-50">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
					</div>
				</div>
				<div class="d-flex feature-h">
					<span class="wrap-icon me-3">
						<span class="icon-home2"></span>
					</span>
					<div class="feature-text">
						<h3 class="heading">Новость</h3>
						<p class="text-black-50">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
					</div>
				</div>
			</div>
			<div class="justify-content-center-ggg mb-5">
				<div class="d-flex feature-h">
					<span class="wrap-icon me-3">
						<span class="icon-home2"></span>
					</span>
					<div class="feature-text">
						<h3 class="heading">Новость</h3>
						<p class="text-black-50">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
					</div>
				</div>
				<div class="d-flex feature-h">
					<span class="wrap-icon me-3">
						<span class="icon-home2"></span>
					</span>
					<div class="feature-text">
						<h3 class="heading">Новость</h3>
						<p class="text-black-50">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
					</div>
				</div>
				<div class="d-flex feature-h">
					<span class="wrap-icon me-3">
						<span class="icon-home2"></span>
					</span>
					<div class="feature-text">
						<h3 class="heading">Новость</h3>
						<p class="text-black-50">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="section bg-light">
		<div class="container">
			<div class="row">
				<div class="col-6 col-lg-3">
					<div class="box-feature mb-4">
						<span class="flaticon-house mb-4 d-block"></span>
						<h3 class="text-black mb-3 font-weight-bold">Проведите подробное исследование рынка</h3>
					</div>
				</div>
				<div class="col-6 col-lg-3">
					<div class="box-feature mb-4">
						<span class="flaticon-house-2 mb-4 d-block-3"></span>
						<h3 class="text-black mb-3 font-weight-bold">Обратитесь к профессионалам<br><br></h3>
					</div>
				</div>
				<div class="col-6 col-lg-3">
					<div class="box-feature mb-4">
						<span class="flaticon-building mb-4 d-block"></span>
						<h3 class="text-black mb-3 font-weight-bold">Оцените свои финансовые возможности</h3>
					</div>
				</div>
				<div class="col-6 col-lg-3">
					<div class="box-feature mb-4">
						<span class="flaticon-house-3 mb-4 d-block-1"></span>
						<h3 class="text-black mb-3 font-weight-bold">Осмотрите объект недвижимости лично</h3>
					</div>
				</div>	

				<div class="col-6 col-lg-3">
					<div class="box-feature mb-4">
						<span class="flaticon-house-4 mb-4 d-block"></span>
						<h3 class="text-black mb-3 font-weight-bold">Будьте готовы к переговорам<br><br></h3>
					</div>
				</div>
				<div class="col-6 col-lg-3">
					<div class="box-feature mb-4">
						<span class="flaticon-building mb-4 d-block-3"></span>
						<h3 class="text-black mb-3 font-weight-bold">Проверьте правовую чистоту недвижимости</h3>
					</div>
				</div>
				<div class="col-6 col-lg-3">
					<div class="box-feature mb-4">
						<span class="flaticon-house mb-4 d-block"></span>
						<h3 class="text-black mb-3 font-weight-bold">Подумайте о долгосрочной перспективе</h3>
					</div>
				</div>
				<div class="col-6 col-lg-3">
					<div class="box-feature mb-4">
						<span class="flaticon-house-1 mb-4 d-block-1"></span>
						<h3 class="text-black mb-3 font-weight-bold">Не торопитесь принимать решение</h3>
					</div>
				</div>	

			</div>
		</div>
	</div>
	<div class="section pt-0">
		<div class="container">
			<div class="row justify-content-center  text-center mb-5">
				<div class="col-lg-5">
					<h2 class="font-weight-bold heading text-primary mb-4">Информация о законодательстве Дубаи</h2>
				</div>
			</div>
			<div class="row justify-content-between mb-5">
				<div class="col-lg-7 mb-5 mb-lg-0">
					<div class="img-about dots">
						<img src="images/hero_bg_2.jpg" alt="Image" class="img-fluid">
					</div>
				</div>
				<div class="col-lg-4">
					<div class="d-flex feature-h">
						<span class="wrap-icon me-3">
							<span class="icon-home2"></span>
						</span>
						<div class="feature-text">
							<h3 class="heading">Владение недвижимостью</h3>
							<p class="text-black-50">Граждане ОАЭ могут спокойно иметь недвижимость, а приехавшим придется инвистировать.</p>   
						</div>
					</div>

					<div class="d-flex feature-h">
						<span class="wrap-icon me-3">
							<span class="icon-person"></span>
						</span>
						<div class="feature-text">
							<h3 class="heading">Разрешение на покупку</h3>
							<p class="text-black-50">Наша компания поможет и преподнесетт вам все нужные документы. Вам останется все подписать.</p>   
						</div>
					</div>

					<div class="d-flex feature-h">
						<span class="wrap-icon me-3">
							<span class="icon-security"></span>
						</span>
						<div class="feature-text">
							<h3 class="heading">Риэлторские услуги</h3>
							<p class="text-black-50">Наша компания также займется и этими вопросами. </p>   
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="site-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-4">
					<div class="widget">
						<h3>Контакты</h3>
						<address>Адрес: 123317, г. Москва, ул. Пресненская набережная, 8с1</address>
						<ul class="list-unstyled links">
							<li><a href="tel://11234567890">+7(900)-888-99-88</a></li>
							<li><a href="tel://97142222222">+(971) 4-222 2222</a></li>
							<li><a href="mailto:info@mydomain.com">info@luxuriaestates.com</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="widget">
						<h3>Страницы</h3>
						<ul class="list-unstyled float-start links">
							<li><a href="index.html">Главная</a></li>
							<li><a href="properties.html">Купить</a></li>
							<li><a href="properties_arenda.html">Арендовать</a></li>
							<li><a href="services.html">Новости</a></li>
							<li><a href="about.html">О нас</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="widget">
						<h3>Ссылки</h3>
						<ul class="list-unstyled links">
							<li><a href="contact.html">Связаться с нами</a></li>
						</ul>
						<ul class="list-unstyled social">
							<li><a href="#"><span class="icon-instagram"></span></a></li>
							<li><a href="#"><span class="icon-twitter"></span></a></li>
							<li><a href="#"><span class="icon-facebook"></span></a></li>
							<li><a href="#"><span class="icon-linkedin"></span></a></li>
							<li><a href="#"><span class="icon-pinterest"></span></a></li>
							<li><a href="#"><span class="icon-dribbble"></span></a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="row mt-5">
				<div class="col-12 text-center">
            <p>Luxuria Estates&copy;<script>document.write(new Date().getFullYear());</script>. Все Права Защищены
            </p>
          </div>
        </div>
      </div>
    </div> 
	<div id="overlayer"></div>
    <div class="loader">
    	<div class="spinner-border" role="status">
    		<span class="visually-hidden">Загрузка...</span>
    	</div>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/tiny-slider.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/navbar.js"></script>
    <script src="js/counter.js"></script>
    <script src="js/custom.js"></script>
  </body>
  </html>
